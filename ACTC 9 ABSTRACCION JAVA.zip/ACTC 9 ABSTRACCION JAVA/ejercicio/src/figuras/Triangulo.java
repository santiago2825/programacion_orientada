
package figuras;


public abstract class Triangulo extends FigurasGeometricas {
    
}
