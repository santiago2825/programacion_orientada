
package figuras;


public class TrianguloEscaleno  extends Triangulo{
     private double base;
     private double altura;

     public void setNombre(String nombre) {
        this.nombre = nombre;
     }

     public String getNombre() {
        return nombre;
     }
    

     public void setBase(double base) {
        this.base = base;
     }

     public double getBase() {
        return base;
     }

     public void setAltura(double altura) {
        this.altura = altura;
     } 

     public double getAltura() {
        return altura;
     }
    
    
     @ Override
     public void calculararea(){
     double area = base*altura/2;
    
     System.out.println("el area del " + nombre + " es:" + area);
    }
}
