
package figuras;


public class rectangulo extends FigurasGeometricas {
    
     private double base;
     private double altura;

     public void setNombre(String nombre) {
        this.nombre = nombre;
     }

     public String getNombre() {
        return nombre;
     } 

    public void setBase(double base) {
        if (base<=0) {
            System.out.println("la base debe ser mayor a cero");
        }else{
        this.base = base;
        }
    }

    public double getBase() {
        return base;
    }
     public void setAltura(double altura) {
         if (altura<=0) {
             System.out.println("la altura debe ser mayor a cero"); 
         }else{
         this.altura = altura;
         }
     }
     public double getAltura() {
        return altura;
     }
    
     @Override
    
     public void calculararea(){
        double area  = base * altura;
          System.out.println("el area del " + nombre + " es:" + area);
    } 
}
