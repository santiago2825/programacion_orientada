
package figuras;

public class Main {
    public static void main(String[] args) {
        
        Circulo obj1 = new Circulo ();
        rectangulo obj2 = new rectangulo();
        TrianguloIsosceles obj3 = new TrianguloIsosceles ();
        TrianguloEscaleno obj4 = new TrianguloEscaleno();
        TrianguloEquilatero obj5 = new TrianguloEquilatero();
        
        obj1.setNombre("circulo");
        obj1.setRadio(10);
        obj1.calculararea();
        
        
        obj2.setNombre("rectangulo");
        obj2.setBase(12);
        obj2.setAltura(6);
        obj2.calculararea();
        
        obj3.setNombre("triangulo isosceles");
        obj3.setBase(7);
        obj3.setAltura(4);
        obj3.calculararea();
        
        obj4.setNombre("triangulo  escaleno");
        obj4.setBase(8);
        obj4.setAltura(5);
        obj4.calculararea();
        
        obj5.setNombre("triangulo equilatero");
        obj5.setLado(23);
        obj5.calculararea();
    }
}
