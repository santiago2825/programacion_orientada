
package figuras;


public class TrianguloEquilatero extends Triangulo {
      
    
    private double lado;

     public void setNombre(String nombre) {
        this.nombre = nombre;
     }

     public String getNombre() {
        return nombre;
     } 
    
    

     public void setLado(double lado) {
        this.lado = lado;
     }

     public double getLado() {
        return lado;
     }
    
    
    
    
     @Override
     public void calculararea(){
     
         if (lado<=0) {
             System.out.println("dato invalido, debe ser mayor a cero");
         }else{
         double area = Math.pow(lado,2)*Math.sqrt(3)/4;
         
             System.out.println("el area del " +nombre+ " es:"+area);
         }
    
    
     }
}
