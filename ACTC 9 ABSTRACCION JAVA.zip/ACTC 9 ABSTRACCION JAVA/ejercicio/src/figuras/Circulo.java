
package figuras;


public class Circulo extends FigurasGeometricas{
    
     final double pi = 3.14;
     private double radio ;
     
   
     public void setNombre(String nombre) {
        this.nombre = nombre;
     }
     public String getNombre() {
        return nombre;
     }

    public void setRadio(double radio) {
        if (radio<=0) {
            System.out.println("dato invalido, debe ser mayor a cero");
        }else{
        this.radio= radio;
        }
    }

    public double getRadio() {
        return radio;
    }
     
     
      @Override
      public void calculararea(){
        
      double area  = pi*(radio*radio); 
          System.out.println("el area del " + nombre + " es:" + area);
  }
}
