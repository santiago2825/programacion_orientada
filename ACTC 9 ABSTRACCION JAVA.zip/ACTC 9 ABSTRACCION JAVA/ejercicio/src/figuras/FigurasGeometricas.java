
package figuras;


public abstract class FigurasGeometricas {
    
    String nombre;
    
    public abstract  void calculararea();
}
