
package estudiante;


public class main {
    public static void main(String[] args) {
        
        // se crea un objeto ( estudiante)
        Clase1 est = new Clase1();
        // se asigna el nombre al estudiante
        est.setNombre("santiago");
        // se asigna la nota al estudiante
        est.setNota(-7);
        // se muestra la informacion del estudiante
        est.mostrarInfo();
    }
   
}
