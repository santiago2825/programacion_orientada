// este programa te dice el nombre y la nota del estudiante
package estudiante;


public class Clase1 {
    //los atributos de forma privada
    private String nombre;
    private double nota;
// se hace un setter para modificar el nombre del estudiante
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    // se hace un getter para obtener el nombre del estudiante
    public String getNombre() {
        return nombre;
    }

    public void setNota(double nota) {
        // se hace una condicion para verificar que la nota ingresada sea menor a 5 y mayor a 0
        if (nota>=0&&nota<5) {
            this.nota=nota;
        }else{
            // si no se cumple la condicion se muestra el mensaje 
            // y se asigna el cero
            System.out.println("nota invalida");
            this.nota=0;
        }
    }

    public double getNota() {
        return nota;
    }
    
    
    // se hace un metodo para mostrar la informacion del estudiante
    public void mostrarInfo(){
        System.out.println("nombre:"+nombre);
        System.out.println("nota: "+nota);
    }
    
    
    
}
