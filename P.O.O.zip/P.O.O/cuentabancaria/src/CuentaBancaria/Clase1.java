// este program de cuenta bancaria se puede depositar y retirar el dinero
package CuentaBancaria;


public class Clase1 {
    //atributos privados 
    private String numeroCuenta;
    private double saldo;

    // se hace un setter para modificar el numero de la cuenta
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }
    //se hace un getter para obtener el numero de la cuenta
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setSaldo(double saldo) {
        // se hace una condicion para verificar el saldo 
        if (saldo>0) {
            this.saldo=saldo;
        }else{
            // si el saldo es negativo se asigna el saldo en cero
        this.saldo=0;
        }
    }

    public double getSaldo() {
        return saldo;
    }
    
    
    

    // metodo depositar: aumenta el saldo si el monto es valido
    public void depositar (double monto){
        // se hace una condicion para verificar si el monto es mayor a cero
        if(monto>0){
            // se concatena el monto al saldo
            saldo+=monto;
            // si el valido el monto se le muestra el siguiente mensaje
            System.out.println("deposito de : " + monto + " realizado. \nsaldo actual: " + saldo);
        }else{
            // si el monto el invalido se le muestra el siguiente mensaje
            System.out.println("el monto a depositar debe ser mayor a cero.");
        }
    }
    //metodo retirar: resta  el monto del saldo 
    public void retirar (double monto){
        // se hace una condicon para verificar que el monto a retirar sea positivo
        if (monto < 0) {
            // si se cumple la condicon se le muestra el siguiente mensaje
            System.out.println("el monto a retirar debe ser positivo");
            // tambien  se valida que haya saldo suficiente para retirar el monto 
           }else if (monto > saldo) {
               // si se cumple se le muestra el siguiente mensaje
               System.out.println("saldo insuficiente.su saldo es :" + saldo);
           }else{
               // sino se cumple las anteriores condicones 
               // se hace el retiro 
               saldo-=monto;
               // y se le muestra el siguiente mensaje
               System.out.println("retiro del monto existoso."+ monto +"\n saldo:" +  saldo);
           }
    }
}
