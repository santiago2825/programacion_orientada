
package CuentaBancaria;


public class main {
    //metodo principal
    public static void main(String[] args) {
        // se crean dos objetos ( cuenta bancarias )
        Clase1 cuenta1 = new Clase1();
        Clase1 cuenta2 = new Clase1();
        
        // se asigna los numeros de las cuentas
        cuenta1.setNumeroCuenta("12345");
         cuenta2.setNumeroCuenta("54321");
         //operaciones con la cuenta1
         System.out.println("cuenta1");
         // se deposita un monto en la cuenta 1
         cuenta1.depositar(1000);
         // se retira un monto e la cuenta1
         cuenta1.retirar(500);
         //operaciones con la cuenta2
         System.out.println("cuenta2");
         // se deposita un monto en la cuenta2
         cuenta2.depositar(500);
         // se retira un monto mayor a saldo de la cuenta
         cuenta2.retirar(1000);
         // y se muestra el  saldo final de la cuenta
         System.out.println(" saldo saldo final es:"+ cuenta1.getSaldo());
         System.out.println(" saldo final es: "+ cuenta2.getSaldo());
    }
}
