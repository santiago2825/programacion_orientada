
package producto;


public class main {
    public static void main(String[] args) {
       // se crea un objeto( producto)
        Clase1 producto=new Clase1();
        
        // se asigna el nombre, precio, el stock del producto
        System.out.println("informacion actual");
        producto.setNombre("celular");
        producto.setPrecio(1500);
        producto.setStock(34);
        //  se muestra la informacion del producto
        producto.mostrarInfor();
        
        // se actualiza la informacion del producto
        System.out.println("informacion actualizada");
        producto.setNombre("celular");
        producto.setPrecio(2000);
        producto.setStock(50);
        // se muestra la informacion actualizada del producto
        producto.mostrarInfor();
        
        
        // se realiza una compra del producto
        producto.vender(20);
        
        // se muestra la informacio final del producto
        producto.mostrarInfor();
        
         
        
        
    }
    
}
