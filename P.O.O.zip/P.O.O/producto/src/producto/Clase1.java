// este programa simula la venta de un producto 
package producto;


public class Clase1 {
    // atributos de forma privada
    private String nombre;
    private int stock;
    private double precio;
   
     //permite moficar el nombre
     public void setNombre(String nombre) {
        this.nombre = nombre;
     }
     // devulve el valor del atributo nombre
     public String getNombre() {
        return nombre;
     }

    public void setStock(int stock) {
        // se hace una condicion para verificar el numero de stock
        if (stock>0) {
            this.stock=stock;
        }else{
            // si no se cumple la funcion le muestra el mensaje 
            // y se asigna el cero por defecto
            System.out.println("stock invalido");
            this.stock=0;
        }
    }

    public int getStock() {
        return stock;
    }
    
     
     // permite modificar el precio
     public void setPrecio(double precio) {
        
        if (precio>=1000) {
            this.precio= precio;
        }else{
            System.out.println("precio invalido");
        }
       }
     // devulve el valor del atributo precio
     public double getPrecio() {
        return precio;
     }
    
    // se crea el metodo vender
    public void vender (int cantidad){
        // se hace una condicon para verificar la cantidad
        if (cantidad<=0) {
            // si se cumple la cantidad se le muestra el mensaje
            System.out.println("cantidad invalida");
            // si la cantidad es mayor al stock 
            // se le muestra el mensaje
        }else if (cantidad> stock) {
            System.out.println("no hay suficiente stock");
        }else{
            // si no se cumple la condicon se realiza venta del producto
            // y se le muestra el stock actualiza despues de la venta
        stock-=cantidad;
            System.out.println("venta realizada: stock restante: "+stock);
        }
     }
    // se crea un metodo de mostrar informacion
    // del nombre, precio y el stock del producto
    public void mostrarInfor(){
        System.out.println("producto: " +nombre+"\nprecio: "+precio+"\nstock: "+stock);
    }
    
    
    
}
