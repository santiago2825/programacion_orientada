// este programa informacion de un libro
package libro;


public class Clase1 {
    // atributos en forma privada
     private String autor;
    private int paginas;
    private String titulo;

    
        // se hace un setter para moficar el titulo
     public void setTitulo(String titulo) {
        this.titulo = titulo;
       }
     //se hace un getter para devolver el valor del atributo titulo
     public String getTitulo() {
        return titulo;
     }
     
     public void setAutor(String autor) {
        this.autor = autor;
     }

     public String getAutor() {
        return autor;
     }

    public void setPaginas(int paginas) {
        // se hace una condicon para verificar el numero de paginas
        if (paginas>10) {
            this.paginas=paginas;
        }else {
            // si la condicion no se cumple se le muestra el mensaje 
            System.out.println("numero de paginas invalido");
            this.paginas=10;
        }
     }

     public int getPaginas() {
        return paginas;
    }
    // se hace un metodo para mostrar la informacion del libro
     public void mostrarInfo(){
         System.out.println("titulo: "+titulo+"\nautor:"+autor+"\nnum paginas: "+paginas);
     }
}
