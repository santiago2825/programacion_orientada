
package libro;


public class main {
   // se crea el metodo principal
    public static void main(String[] args) {
        // se crea un objeto(libro)
        Clase1 libro = new Clase1();
        // se le asigna el autor el titulo y el numero de las paginas del libro
        libro.setAutor("santiago");
        libro.setTitulo("el hombre lobo");
        libro.setPaginas(76);
        
        // se muestra la informacion del libro
        libro.mostrarInfo();
    }
    
    
}
