
package empleado;


public class main {
    // se crea el metodo principal
    public static void main(String[] args) {
        // se crea un objeto (empleado)
        Clase1 empleado = new Clase1();
        // se le asigna el nombre y el salario al empleado
        System.out.println("saldo actual");
        empleado.setNombre("santiago");
        empleado.setSalario(1400000);
        // se muestra la informacion en consola
        empleado.mostrarInfo();
        
        // se llama ub setter de salario para modificar el salario
        // despues de actualizar el salario se lo muestra en consola
        System.out.println("saldo actualizado:");
        empleado.setNombre("santiago");
        empleado.setSalario(2000000);
        empleado.mostrarInfo();
        
        // se llama el metodo de aumentarSalario
        // luego se aumenta el salario en porcentaje 
        // al final se muestra el salario final en consola
        System.out.println("aumneto en porcentaje:");
        empleado.setNombre("santiago");
        empleado.aumentarSalario(10);
        empleado.mostrarInfo();
    }
}
