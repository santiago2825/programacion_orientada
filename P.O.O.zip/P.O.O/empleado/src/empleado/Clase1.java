// este programada te crea un empleado con su salario
package empleado;


public class Clase1 {
    // atributos en forma privada
    private String nombre;
    private double salario;

        // se hace un setter en el atributo nombre 
     // para poder modificarlo
     public void setNombre(String nombre) {
        this.nombre = nombre;
     }
     // se hace un getter para devolver el valor del atributo nombre
     public String getNombre() {
        return nombre;
     }
        // se hace un setter para modificar el salario del empleado
     public void setSalario(double salario) {
         // se hacer una condicon para verificar el salario ingresado
         if (salario>1300000) {
            this.salario = salario;
         }else{
             // si la condicion no se cumple se le muestra el mensaje
            System.out.println("salario insuficiente");
            this.salario=1300000;
         }
     }
    public double getSalario() {
        return salario;
    }
    // se crea un metodo de aumentarSalario 
    public void aumentarSalario(double porcentaje){
        // se hace una condicion para verificar el porcentaje
        if (porcentaje<0) {
            // si la condicion se cumple le aparece el mensaje
            System.out.println("porcentaje invalido");
        }else{
            // si la condicion no se cumple se hace su respectiva operacion 
            double aumento= salario*(porcentaje/100);
            // se concatenan 
            salario+= aumento;
        }
    }
    // se crea un metodo de mostrarInfo
    // para mostrar el nombre y salario del empleado
    public void mostrarInfo (){
        System.out.println("empleado: "+nombre+"\n"+"salario actual: " +salario);
    }
    
    
    
}
